import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TATA Banking Services - User Management';      //instance variable of app

  //creating date object
  todaysDate =new Date();

  //In typeScript, constructors can't be overloaded. only one constructor per class

  constructor()
  {
    //setInterval() asynchronous function
    //Arrow function ( =>)

    setInterval(()=>{
      this.todaysDate = new Date();
    },1000);
  }
}
