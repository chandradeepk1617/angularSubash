import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalcService {

  constructor() { }

  addition(fn: number, sn: number):number{
    return (fn+sn);
  }

  multiply(fn:number , sn:number):number
  {
    return (fn*sn)
  }
}
