import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { ListUserComponent } from './components/list-user/list-user.component';
import { SqrtPipe } from './pipes/sqrt.pipe';

//to handle HttpClient
import { HttpClientModule } from '@angular/common/http';
import { SearchPipe } from './pipes/search.pipe';

@NgModule({
  declarations: [   //registering all user defined components, directives & pipes
    AppComponent,
    HomeComponent,
    LoginComponent,
    AddUserComponent,
    EditUserComponent,
    ListUserComponent,
    SqrtPipe,
    SearchPipe    
  ],
  imports: [        //registering all predefined and user defined modules
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule, //ReactiveFormModule for Reactive forms
    FormsModule,
    HttpClientModule  //HttpClientModule for HttpClient
  ],
  providers: [],    //registering user defined services
  bootstrap: [AppComponent] //specifing startup component
})
export class AppModule { }
