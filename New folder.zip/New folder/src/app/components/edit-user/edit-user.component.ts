import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  currentId:number;
  editForm:FormGroup;
  submitted:boolean=false;
  constructor(private formBuilder: FormBuilder, private router:Router,private userService: UserService, private route:ActivatedRoute) {
    this.route.params.subscribe(params =>{
      this.currentId =params['id'];
    })
   }
  
  ngOnInit() {
    if(localStorage.usr!=null)
    {
      this.editForm =this.formBuilder.group({
        id:[this.currentId],
        firstName:[{value:'',disabled:true},[Validators.required, Validators.pattern("[A-Z][A-Z a-z]{2,14}")]],
        lastName:[{value:'',disabled:true},[Validators.required]],
        age: ['',[Validators.required,Validators.min(20),Validators.max(30)]],
        mobileNumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]],
        email:['',[Validators.required,Validators.email]],
        password:['',[Validators.required, Validators.minLength(6),Validators.maxLength(12)]]
      });

      this.userService.getUserById(this.currentId).subscribe(data =>{
        console.log(data);
        this.editForm.setValue(data);
      },
    err=>{
      console.log(err.stack);
    })
    }
    else{
      this.router.navigate(['/login']);
    }
  }


  updateUser(){
    this.submitted =true;
    if(this.editForm.invalid)
    {
      return;
    }

    console.log(this.editForm.value);

    this.userService.updateUserById(this.editForm.getRawValue()).subscribe(data =>{
      alert(`${this.editForm.controls.firstName.value} record updated successfully...!`);
      this.router.navigate(['list-user']);
    },err =>{
      console.log(err.stack);
    })
  }
  logOutUser()
  {
    if(localStorage.usr!=null)
    {
      localStorage.removeItem("usr");
      this.router.navigate(['/login']);
    }
  }

}
