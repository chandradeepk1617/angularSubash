import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //creating form group objects
  loginForm: FormGroup;

  submitted:boolean =false;
  //Constructor Dependency Injection. It makes your application loosely typed.

  //formBuilder to build form elements with default values and attributes
  //
  constructor(private formBuilder: FormBuilder, private router: Router) { }

  //Life cycle hook
  ngOnInit() {
    this.loginForm = this.formBuilder.group(
      {
        email:['',Validators.required],
        password:['',Validators.required]
      }
    );
  }

  verifyLogin()
  {
    this.submitted =true;
    if(this.loginForm.invalid){
      return; 
    }

    let usr =this.loginForm.controls.email.value;
    let pass = this.loginForm.controls.password.value;
    if(usr == "admin@gmail.com" && pass == "admin123")
      {
        localStorage.usr = usr;
        sessionStorage.usr = usr;
        this.router.navigate(['list-user'])
      }
      else{
        this.invalidLogin =true;
      }
  }
  invalidLogin:boolean =false;
}
