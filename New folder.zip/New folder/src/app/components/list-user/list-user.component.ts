import { Component, OnInit } from '@angular/core';
import { CalcService } from '../../services/calc.service';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

  // searchText = "Amit";
  searchText:any;
  //to handle list of users
  users: User[];

  constructor(private userService:UserService, private router: Router) { }

  ngOnInit()
  {
    if(localStorage.usr!=null)
    {
      this.userService.getAllUsers().subscribe(data=>{
        this.users =data;
        console.log(this.users);

      },
    err =>{
      //on reject or error
      console.log(err.stack);
    })
    }
    else{
      this.router.navigate(['/login']);

    }
  }

  //logout 
  logOutUser()
  {
    if(localStorage.usr!=null)
    {
      localStorage.removeItem("usr");
      this.router.navigate(['/login']);
    }
  }

  //add user
  addUser()
  {
    this.router.navigate(['/add-user']);
  }

  //edit user
  editUser(user)
  {
    this.router.navigate(['edit-user',user.id]);
  }

  //delete user
  deleteUser(user: User):void{
    let result = confirm("Do you want to delete user?");
    if(result)
    {
      this.userService.deleteUserById(user.id).subscribe(data=>{
        this.users=this.users.filter(u=> u!== user);
      },
    err=>{
      console.log(err.stack);
    });
    alert(`${user.firstName} record is deleted`)
    }

  }
  // sum:number;
  // product:number;
  // //Injecting calculator service
  // constructor(private calcService: CalcService) { }

  // ngOnInit() {

  //   this.sum =this.calcService.addition(10,20);
  //   this.product =this.calcService.multiply(10,20);
  // }




}
