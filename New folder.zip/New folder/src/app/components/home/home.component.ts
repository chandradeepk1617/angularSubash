import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  //implicitly typed the datatype, title will be  of string type
  title = "welcome to angular 8";

  //if you delcare any variable without initialising it, TypeScript will consider it as undefined type
  //companyName;
  constructor() { }

  ngOnInit() {
  }

}
